# Exercise 5: AMSI Bypasses
1. Run AMSI bypass 1 and load seatbelt from memory using the Execute-Seatbelt.ps1 script 
2. Run AMSI bypass 2 and load seatbelt from memory using the Execute-Seatbelt.ps1 script
