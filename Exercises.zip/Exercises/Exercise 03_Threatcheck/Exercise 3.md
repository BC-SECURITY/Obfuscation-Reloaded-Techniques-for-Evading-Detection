# Exercise 3: Threatcheck

1. Utilize launcher.ps1 and ThreatCheck.exe 
2. Determine the line(s) of code that are being flagged by Defender.
3. Try Obfuscating the detected line(s) of code so it is no longer flagged by Defender. You may not be able to complete it within the provided time but the isntructor will show some posisble answers.
4. RUn Threatcheck with: `Threatcheck.exe -f Launcher.ps1 -e Defender`
![image](https://user-images.githubusercontent.com/20302208/184451338-8ce214cb-370e-472e-8542-0f1da99bb9b0.png)

<details>
<summary>Hint</summary>
Initally, lines 1-4 are being flagged for their AMSI and ETW bypass. Try removing those and coming back to them later.

The lines 9 – 12 are being flagged in ThreatCheck
  
![image](https://user-images.githubusercontent.com/20302208/184451949-569d0f25-2dd6-4ca5-bed1-5973038dee17.png)
</details>


