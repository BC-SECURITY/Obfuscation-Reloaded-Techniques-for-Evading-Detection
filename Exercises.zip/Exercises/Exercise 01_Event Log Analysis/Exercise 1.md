# Exercise 1: Logs
Analyze the Windows Event Logs for suspicious behavior using Event Viewer open the provided log files from the Git Repo.

1. Are there any logs that look suspicious to you?
2. If so, why? 
3. Do you think the executed code could have been changed to make it less suspicious?
